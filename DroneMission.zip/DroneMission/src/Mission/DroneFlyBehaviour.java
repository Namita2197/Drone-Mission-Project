package Mission;

public interface DroneFlyBehaviour {

    public void performMission() throws Exception;

}
